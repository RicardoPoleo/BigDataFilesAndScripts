//

println("==========================================================================")
println("Pipeline code . Read data form HDFS, JOINED AND performed analysis")
println("READ HDFS -> SPARK -> TRANSFORMATION - > WRITE BACK TO HDFS")
println("==========================================================================")

import org.apache.spark.sql.functions._

//load files
val customers = spark.read.format("csv").option("header", "true").load("hdfs://localhost:9000/user/input/adventureworksc3/customers.csv")
val employees = spark.read.format("csv").option("header", "true").load("hdfs://localhost:9000/user/input/adventureworksc3/employees.csv")
val orders = spark.read.format("csv").option("header", "true").load("hdfs://localhost:9000/user/input/adventureworksc3/orders.csv")
val productcategories = spark.read.format("csv").option("header", "true").load("hdfs://localhost:9000/user/input/adventureworksc3/productcategories.csv")
val products = spark.read.format("csv").option("header", "true").load("hdfs://localhost:9000/user/input/adventureworksc3/products.csv")
val productsubcategories = spark.read.format("csv").option("header", "true").load("hdfs://localhost:9000/user/input/adventureworksc3/productsubcategories.csv")
val vendorproduct = spark.read.format("csv").option("header", "true").load("hdfs://localhost:9000/user/input/adventureworksc3/vendorproduct.csv")
val vendors = spark.read.format("csv").option("header", "true").load("hdfs://localhost:9000/user/input/adventureworksc3/vendors.csv")





orders.join(employees, "EmployeeID").
withColumn("qty",col("OrderQty").cast("int")).
withColumn("price",col("UnitPrice").cast("decimal(12,4)")).
withColumn("Freight1",col("Freight").cast("decimal(12,4)")).
withColumn("value",col("qty")* col("price")).
groupBy("Territory").
agg(sum("value").as("totalsales"),avg("Freight").as("Freight1")).
orderBy(desc("totalsales")).
limit(5).show()



// Example : Calculate the average order value per customer by children groups
println("Calculate the average order value per customer by children groups")
ordersDF.join(customers, "CustomerKey").
join(products, "ProductKey").
withColumn("cd",col("TotalChildren").cast("int")).
withColumn("childgroup", when($"cd" === 0, "No Child").when($"cd" === 1 , "one Child").when($"cd" >= 2 && $"cd" <= 3, "2-3 Child").otherwise("4+ Child")).
withColumn("qty",col("OrderQuantity").cast("int")).
withColumn("price",col("ProductPrice").cast("decimal(12,4)")).
withColumn("value",col("qty")* col("price")).
groupBy("childgroup").
agg(sum("value").as("totalsales"),avg("value").as("Average_Sales"),max("value").as("MAX_Sales"),min("value").as("Min_Sales"),count("OrderNumber").as("Count_Products"),countDistinct("OrderNumber").as("totalOrders")).
orderBy(desc("totalsales")).show()




SCALA + SPARK  = SCALASPARK
PYTHON + SPARK = PYSPARK